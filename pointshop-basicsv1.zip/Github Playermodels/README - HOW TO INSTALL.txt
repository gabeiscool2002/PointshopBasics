Go to root>garrysmod>addons>pointshop-master>lua>pointshop>items>playermodels and copy the folders into the folder.
