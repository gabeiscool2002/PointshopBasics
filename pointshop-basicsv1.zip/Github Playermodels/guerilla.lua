ITEM.Name = 'Guerilla'
ITEM.Price = 250
ITEM.Model = 'models/player/t_guerilla.mdl'