ITEM.Name = 'MARSOC'
ITEM.Price = 300
ITEM.Model = 'models/player/ct_urban.mdl'