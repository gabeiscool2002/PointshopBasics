ITEM.Name = 'Fast Zombie'
ITEM.Price = 350
ITEM.Model = 'models/Zombie/Fast.mdl'
