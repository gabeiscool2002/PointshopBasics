ITEM.Name = 'Combine Elite'
ITEM.Price = 350
ITEM.Model = 'models/player/combine_super_soldier.mdl'