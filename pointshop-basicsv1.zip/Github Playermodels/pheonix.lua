ITEM.Name = 'Pheonix'
ITEM.Price = 250
ITEM.Model = 'models/player/t_phoenix.mdl'