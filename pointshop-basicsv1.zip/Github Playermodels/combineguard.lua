ITEM.Name = 'Combine Guard'
ITEM.Price = 300
ITEM.Model = 'models/player/combine_soldier_prisonguard.mdl'