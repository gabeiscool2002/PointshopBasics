ITEM.Name = 'Leet'
ITEM.Price = 250
ITEM.Model = 'models/player/t_leet.mdl'