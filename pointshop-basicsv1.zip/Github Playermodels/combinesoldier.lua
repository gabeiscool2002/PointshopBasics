ITEM.Name = 'Combine Soldier'
ITEM.Price = 300
ITEM.Model = 'models/player/combine_soldier.mdl'