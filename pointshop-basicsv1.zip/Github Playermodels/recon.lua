ITEM.Name = 'Recon'
ITEM.Price = 300
ITEM.Model = 'models/player/ct_gign.mdl'