ITEM.Name = 'Chell'
ITEM.Price = 300
ITEM.Model = 'models/Player/chell.mdl'