ITEM.Name = 'Spooky Scary Skeleton'
ITEM.Price = 650
ITEM.Model = 'models/player/skeleton.mdl'