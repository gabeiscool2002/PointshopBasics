ITEM.Name = 'Navy Seal'
ITEM.Price = 300
ITEM.Model = 'models/player/ct_urban.mdl'