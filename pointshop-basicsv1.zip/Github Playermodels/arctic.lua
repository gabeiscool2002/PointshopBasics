ITEM.Name = 'Arctic'
ITEM.Price = 250
ITEM.Model = 'models//player/t_arctic.mdl'